using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class MainBrick : MonoBehaviour

{
    public DeathLine deathLine;

    private ScoreManager scoreManager;
    [SerializeField] private int pv;
    private void Awake()
    {   
        scoreManager = FindAnyObjectByType<ScoreManager>();
        changecolor();
    }
    private void OnCollisionEnter2D(Collision2D _collision)
    {
        if (_collision.gameObject.tag == "Ball")
        {
            deathLine.bricks.Remove(this.gameObject);
            pv -= 1;
            changecolor();
            if (pv < 0)
            { Destroy(gameObject);

                scoreManager.AddToScore(100);
            }

        }
    }

    private void changecolor()
    {
switch (pv)
        {
            case 0:
                gameObject.GetComponent<SpriteRenderer>().color = Color.green;
                break;
            case 1:
                gameObject.GetComponent<SpriteRenderer>().color = Color.blue;
                break;
            case 2:
                gameObject.GetComponent<SpriteRenderer>().color = Color.yellow;
                break;
            case 3:
                gameObject.GetComponent<SpriteRenderer>().color = Color.magenta;
                break;
        }

    }
}
