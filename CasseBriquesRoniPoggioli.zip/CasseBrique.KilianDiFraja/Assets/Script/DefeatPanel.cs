using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class DefeatPanel : MonoBehaviour
{
    //on veut reload la scene en appuyant sur le bouton une fois mort

    public void ReloadScene()
    {
        SceneManager.LoadScene("CasseBriqueRoni");
          


    }
}
