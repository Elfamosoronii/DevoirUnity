using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DeathLine : MonoBehaviour
   
{
    [SerializeField] private GameObject DeathPopUp;
    [SerializeField] private GameObject WinPopUp;

    public List<GameObject> bricks = new List<GameObject>();
    private void Awake()
    {
        DeathPopUp.SetActive(false); 
        WinPopUp.SetActive(false);
    }

    public void Update()
    {
        if (bricks.Count <= 0)
        {
            Time.timeScale = 0;
            WinPopUp.SetActive(true); 


        }
    }
    // Cette m�thode est appel�e lorsqu'un autre collider entre en collision avec la ligne de mort
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Collision qui tue la balle
        if (collision.CompareTag("Ball"))
        {
            Destroy(collision.gameObject); 
            GameOver(); 
        }
    }

    // M�thode appel�e lorsque le jeu est termin�
    private void GameOver()
    {
        DeathPopUp.SetActive(true);
    }
}